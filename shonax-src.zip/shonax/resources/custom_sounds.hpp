#pragma once

extern unsigned char welcome[];
extern unsigned char metallic[];
extern unsigned char cod[];
extern unsigned char bubble[];
extern unsigned char stapler[];
extern unsigned char bell[];
extern unsigned char flick[];
extern unsigned char kill1[];
extern unsigned char kill2[];
extern unsigned char kill3[];
extern unsigned char kill4[];
extern unsigned char kill5[];
extern unsigned char kill6[];
extern unsigned char kill7[];
extern unsigned char kill8[];
extern unsigned char kill9[];
extern unsigned char kill10[];
extern unsigned char kill11[];